# pyspark-iceberg-reader
A purely PySpark-based reader for Apache Iceberg tables designed to operate only with file access and without stupid idiot catalogs.
