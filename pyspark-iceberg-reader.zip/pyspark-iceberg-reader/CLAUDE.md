# CLAUDE.md

Operating guide for working in the **`pyspark-iceberg-reader`** repository.
`specification.md` is the source of truth; this file is the short version plus the rules that
are easy to get wrong. When they disagree, the spec wins — update both.

---

## What this project is

A source-only Python/PySpark package that reads an **Apache Iceberg v2** table into a Spark
`DataFrame`, given only a `*.metadata.json` path and the filesystem access the cluster already
has. Runs on **Databricks Runtime 17.3 LTS** (Spark 4.0.0, Python 3.11+). Read-only. No wheel,
no catalog, no external auth.

Top-level entry point:

```python
read_iceberg_table(metadata_location, *, snapshot_id=None, normalizer=None, spark=None) -> DataFrame
```

---

## Non-negotiable rules

1. **v2 only.** Gate `format-version == 2` in one place (`metadata.py`). v3 is a future seam, not
   today's job.
2. **Never guess the snapshot.** Default to the metadata's `current-snapshot-id`. An explicit
   `snapshot_id` must exist or raise `SnapshotNotFoundError`. **Never** pick "latest", never infer
   from timestamps.
3. **No cluster JARs, ever.** The `iceberg-spark-runtime` path is off the table — it needs a
   catalog the platform forbids. Do not reintroduce it.
4. **All bulk reads go through Spark** — manifests (Avro) and data/deletes (Parquet). The driver
   only ever holds metadata-scale data (file lists). Never read data on the driver.
5. **Filesystem access is Spark's.** No boto3/adlfs/SDKs, no credentials in code, no auth calls.
   Read even the small `metadata.json` via `spark.read.text(..., wholetext=True)`.
6. **Correctness over completeness.** A missed delete = wrong rows = the worst bug. If something
   is unsupported, raise a specific error rather than return a plausible-but-wrong DataFrame.

---

## Architecture in one breath

```
metadata.py  →  planning/native.py  →  ScanPlan (IR)  →  execution.py  →  DataFrame
```

`NativePlanner` emits a `ScanPlan` (data files + delete files, each with sequence number,
partition, spec id). `execution.py` is the single Spark engine that reads data and applies
deletes. Put shared Spark logic there, not in the planner.

Module map (see spec §6 for the full tree):
- `reader.py` — orchestration / public function
- `metadata.py` — parse metadata.json, resolve schema + snapshot
- `planning/base.py` — `ScanPlan` IR + `ScanPlanner` protocol
- `planning/native.py` — `NativePlanner` (Spark Avro)
- `manifests.py` — manifest-list/manifest reading + inheritance
- `schema.py` — Iceberg↔Spark types, field-ID metadata, projection
- `execution.py` — read + delete application + final projection
- `deletes.py` — position + equality delete helpers
- `paths.py` — path scheme/mount normalization
- `errors.py` — typed exceptions

---

## The four things that are easy to get wrong

Read spec §4.5–4.8 before touching these.

1. **Manifest inheritance.** Sequence numbers / snapshot id may be null and inherited from the
   manifest list — **only** when `status == ADDED (1)`. For `EXISTING (0)`/`DELETED (2)` they must
   be explicit. Don't union manifests before resolving inheritance per owning manifest.
2. **"Live" files.** Keep `status ∈ {ADDED, EXISTING}`; drop `DELETED` tombstones. Applies to both
   data and delete manifests.
3. **Delete application by sequence number, same partition:**
   - **Position** delete applies when `delete.seq >= data.seq` and it names the data file's path →
     anti-join on `(file_path, pos)` against `(_metadata.file_path, _metadata.row_index)`.
   - **Equality** delete applies when `delete.seq > data.seq` (strict) and same partition →
     sequence-gated, partition-scoped, **null-safe** (`<=>`) anti-join on the equality columns.
4. **Schema evolution → read by field ID, not name.** Build the Spark read schema from the current
   Iceberg schema with `metadata={"parquet.field.id": id}` per field, enable
   `spark.sql.parquet.fieldId.read.enabled`, read with `.schema(...)`, then cast promoted types.
   Output is the table's data columns only — **do not** synthesize partition columns (hidden
   partitioning, spec §4.9).

---

## Running tests locally (Windows)

The Python launcher (`py`) is used on this machine — `python` and `python3` are not on PATH.

**First-time setup** (installs pyspark + pytest into the system Python 3.14 site):

```
py -3.14 -m pip install -e ".[dev]"
```

**Run all non-cluster tests** (the normal inner loop):

```
py -3.14 -m pytest -m "not cluster" -v
```

**Run a specific test file:**

```
py -3.14 -m pytest tests/test_paths.py -v
```

The `spark` fixture in `conftest.py` starts a local `local[2]` Spark session. It includes
`-Djava.security.manager=allow` so the session starts correctly on Java 18+ (where the
security manager was removed). The flag is harmless on Java 17.

Cluster-only tests (`@pytest.mark.cluster`) require a real DBR 17.3 session and are always
excluded from the local run.

---

## Dev workflow

- Validate runtime assumptions first: `tests/test_runtime_capabilities.py` must pass on a real
  DBR 17.3 cluster (proves Avro read, parquet field-ID read, and `_metadata.row_index`). If
  `row_index` misbehaves, sort out the position-delete fallback before building more.
- Iterate against tiny committed fixtures in `tests/fixtures/` (copy-on-write, position, equality,
  mixed, schema-evolved). Don't depend on real platform data.
- `spark` is always injected, never created deep in the stack. No session-global conf changes that
  aren't scoped/restored.

---

## Conventions

- Python 3.11 typing; `from __future__ import annotations`; dataclasses for the IR.
- `logging`, not `print`. No `dbutils`, no `display` — must run in a plain Python task.
- DRY: one type-mapping table, one path-normalizer, one delete-join helper. If you're writing the
  same Spark transform in two planners, it belongs in `execution.py`.
- Every public function names the spec section it implements in its docstring.

## Do NOT

- add a JAR or a required pip dependency; pick the latest snapshot; read the whole `data/` folder;
  materialize data on the driver; authenticate to any service; or silently skip a delete file you
  don't understand (raise instead).
