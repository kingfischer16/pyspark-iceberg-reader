# pyspark-iceberg-reader — Implementation Status

Source of truth for spec details: [`docs/specification.md`](docs/specification.md).
Architecture overview: [`CLAUDE.md`](CLAUDE.md).

---

## Done

### Tooling
- [x] `pyproject.toml` — package config, dev extras (`pyspark[avro]==4.0.0`, `pytest>=8`), pytest markers
- [x] `.gitignore` — whitelist approach; tracks only `.py .md .toml .yml .yaml .json .avro .parquet`
- [x] `.github/workflows/ci.yml` — runs `pytest -m "not cluster"` on every PR commit (Python 3.11, Java 17, local-mode Spark)
- [x] `scripts/generate_fixtures.py` — regenerate committed Parquet fixtures with Iceberg field IDs (pyarrow only, no Java)

### Source modules
- [x] `src/pyspark_iceberg_reader/errors.py` — typed exception hierarchy (`IcebergReaderError` + 5 subtypes)
- [x] `src/pyspark_iceberg_reader/metadata.py` — domain dataclasses (incl. `metadata_location`); `read_metadata()`, `resolve_snapshot()`, `_parse_metadata_json()`
- [x] `src/pyspark_iceberg_reader/paths.py` — path scheme normalisation, relative-path resolution, `validate_scheme`
- [x] `src/pyspark_iceberg_reader/schema.py` — Iceberg→Spark type conversion, field-ID `StructType` builder
- [x] `src/pyspark_iceberg_reader/planning/base.py` — `DataFileTask`, `DeleteFile`, `ScanPlan`, `ScanPlanner` Protocol
- [x] `src/pyspark_iceberg_reader/manifests.py` — manifest list/file reading, inheritance (§4.5), live-file filtering (§4.6); path normalisation for manifest lookup
- [x] `src/pyspark_iceberg_reader/planning/native.py` — `NativePlanner` (Spark Avro)
- [x] `src/pyspark_iceberg_reader/deletes.py` — position deletes with seq gate (§7.6); equality deletes with null-safe partition (§7.7)
- [x] `src/pyspark_iceberg_reader/execution.py` — shared read engine; unified grouped mode (always adds `_seq`); schema evolution
- [x] `src/pyspark_iceberg_reader/planning/__init__.py` — sub-package marker
- [x] `src/pyspark_iceberg_reader/reader.py` — `read_iceberg_table()` top-level entry point
- [x] `src/pyspark_iceberg_reader/__init__.py` — exports `read_iceberg_table`

### Tests (124 passing locally — `py -3.14 -m pytest -m "not cluster" -v`)
- [x] `tests/conftest.py` — session-scoped `local[2]` SparkSession fixture
- [x] `tests/test_metadata.py` — 17 tests (16 pure Python + 1 Spark integration)
- [x] `tests/test_paths.py` — 43 pure Python tests
- [x] `tests/test_schema.py` — 30 tests (pure Python + local Spark)
- [x] `tests/test_native_planner.py` — 15 pure Python tests (Row objects, no Spark, no I/O)
- [x] `tests/test_deletes_position.py` — 5 Spark tests
- [x] `tests/test_deletes_equality.py` — 5 Spark tests
- [x] `tests/test_schema_evolution.py` — 8 Spark end-to-end tests (execution.execute_scan_plan)
- [x] `tests/test_runtime_capabilities.py` — 4 `@pytest.mark.cluster` stubs (skipped locally)

### Fixtures
- [x] `tests/fixtures/v2_single_snapshot.metadata.json`
- [x] `tests/fixtures/v2_empty_table.metadata.json`
- [x] `tests/fixtures/copy_on_write/data/part-0.parquet` — id int64 fid=1, name fid=2 (5 rows)
- [x] `tests/fixtures/equality_deletes/data/part-0.parquet` — id fid=1, name fid=2, category fid=3 (5 rows)
- [x] `tests/fixtures/equality_deletes/deletes/part-0.parquet` — id fid=1, rows id=2,4
- [x] `tests/fixtures/schema_evolved/v1_data/part-0.parquet` — id int32 fid=1, name fid=2 (rows 1,2)
- [x] `tests/fixtures/schema_evolved/v2_data/part-0.parquet` — id int64 fid=1, name fid=2, category fid=3 (rows 3,4)

---

## To Do

### Cluster integration tests (run on DBR 17.3)

- [x] `tests/test_integration.py` — 14 `@pytest.mark.cluster` tests: 10 existing (simple read, equality deletes, schema evolution, explicit/default snapshot, empty table, bad snapshot error, `_metadata.row_index`) + 4 oracle comparisons (PyIceberg `StaticTable` row-for-row parity for simple, eq_deletes, schema_evolved, explicit snapshot)
- [x] `databricks.yml` — Asset Bundle job definition; serverless compute, no hardcoded credentials
- [x] `scripts/cluster_test_runner.py` — `spark_python_task` entry point for the bundle job

Run with:
```
databricks bundle deploy --profile <your-profile>
databricks bundle run integration_tests --profile <your-profile>
```

### Nice to have

- [ ] `tests/fixtures/manifests/` — Avro manifest list + manifest files for testing `manifests.py` I/O locally (currently the I/O path is cluster-only; logic is tested via pure-Python Row objects)
- [ ] Mixed-deletes fixture (`tests/fixtures/mixed_deletes/`) — a single data file with both position and equality deletes applied together
